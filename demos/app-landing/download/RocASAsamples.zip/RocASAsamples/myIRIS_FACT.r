
print("hello Greg...welcome to R")

library('ggplot2')

data = read.table('/home/microcarbon/Desktop/RocASAsamples/iris_tab.txt', header = TRUE)
Sp = data$species; # species
SL = data$sepal_length; # sepal length
SW = data$sepal_width; # sepal width
PL = data$petal_length; # petal length
PW = data$petal_width; # petal width
dataframe = data.frame(SL, SW, PL, PW)
print (dataframe)
myFA <-  factanal(dataframe, 1, rotation="varimax")
print(myFA, digits=2, cutoff=.3, sort=TRUE)
# plot factor 1 by factor 2 
load <- myFA$loadings[,1:2] 
plot(load,type="n") # set up plot 
text(load,labels=names(dataframe),cex=.7) # add variable names
print("goodbye Greg...leaving R")
#q()